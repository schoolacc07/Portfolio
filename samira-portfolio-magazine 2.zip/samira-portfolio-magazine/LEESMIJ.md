# Samira's Portfolio 2026 · magazine-layout

Open `index.html` in je browser.

## Pagina's
- `index.html`: home met intro en de sneak peek (Studio Yumi × Flordi)
- `cases.html`: alle cases in een raster
- `project.html#slug`: de pagina van één case (bv. `project.html#roots`)
- `about.html`: about me, stress-o-meter en blast from the past
- `contact.html`: let's work together, mail me / bel me tonen je gegevens

## Tekst aanpassen
Alles staat in `assets/js/data.js`:
- `SITE`: je mails, gsm, opleiding en LinkedIn (vul `linkedin` in, dan verschijnt hij op contact)
- per project: `rol` (mijn rol) en `geleerd` (wat ik leerde) zijn voorstellen, pas ze gerust aan
